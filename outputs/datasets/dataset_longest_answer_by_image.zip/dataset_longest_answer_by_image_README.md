# dataset_longest_answer_by_image

Version by-image del dataset `dataset_longest_answer`.

- Input de entrenamiento: imagen + `question_es`.
- Target: `answer_es`, elegido como la respuesta original mas larga del caso.
- Si un caso tiene varias imagenes, se genera una fila por imagen.
- Las imagenes no se incluyen en el zip; se resuelven por `image_id` desde `data/iiyi/images_final/`.

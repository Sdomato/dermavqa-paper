# llm_synthesized_answer

Dataset enriquecido DermaVQA-IIYI listo para baseline de fine-tuning textual y futuro fine-tuning VQA multimodal.

## Archivos

- `dermavqa_iiyi_llm_synthesized_answer_finetune.jsonl`: versi?n JSONL limpia.
- `dermavqa_iiyi_llm_synthesized_answer_finetune.csv`: versi?n CSV equivalente.
- `dermavqa_iiyi_llm_synthesized_answer_finetune.zip`: paquete para subir a Colab/Kaggle.
- `manifest.json`: conteos, columnas y contrato del dataset.

## Interfaz baseline texto

- Input: `question_es`.
- Output: `answer_es`.
- Ignorar durante este baseline: `image_path`, `image_id`.

## Interfaz futura VQA

- Input: `image_path` + `question_es`.
- Output: `answer_es`.

## Columnas

- `split`: train, valid o test.
- `encounter_id`: identificador del caso cl?nico.
- `image_id`: identificador de imagen.
- `image_path`: ruta local de la imagen.
- `question_es`: pregunta en espa?ol.
- `answer_es`: respuesta enriquecida sintetizada a partir de todas las respuestas originales.

## Conteos

- Casos ?nicos: 998.
- Filas por imagen: 2944.
- Filas por split: {'test': 314, 'train': 2473, 'valid': 157}.
- Casos por split: {'test': 100, 'train': 842, 'valid': 56}.

## Validaci?n

- Respuestas vac?as: 0.
- Preguntas vac?as: 0.
- Rutas de imagen faltantes: 0.
- Filas JSONL: 2944.
- Filas CSV: 2944.

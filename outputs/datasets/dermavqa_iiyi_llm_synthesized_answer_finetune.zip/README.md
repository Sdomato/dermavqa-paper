# Dataset enriquecido (`dataset_enriched`)

Dataset DermaVQA-IIYI enriquecido con una respuesta sintetizada por LLM por
caso. Es el artefacto de Santino para baselines textuales y futuro fine-tuning
VQA multimodal con LoRA/QLoRA.

## Artefactos

- `dermavqa_iiyi_llm_synthesized_answer_finetune.jsonl`: version JSONL final.
- `dermavqa_iiyi_llm_synthesized_answer_finetune.csv`: version CSV equivalente.
- `dermavqa_iiyi_llm_synthesized_answer_finetune.zip`: paquete para
  Colab/Kaggle con JSONL, CSV, README y manifest.
- `manifest.json`: contrato local de columnas, conteos y validaciones.

## Generacion

- Fuente: `data/iiyi/train.json`, `data/iiyi/valid_ht.json` y
  `data/iiyi/test_ht_spanishtestsetcorrected.json`.
- Script revisado: `src/build_llm_synthesized_dataset.py`.
- Unidad de sintesis: un `encounter_id` por caso clinico.
- Pregunta: `query_title_es` + salto de linea + `query_content_es`.
- Respuestas fuente: `responses[*].content_es`, filtradas vacias y
  deduplicadas para el prompt.
- Entrada al LLM: solo texto de pregunta y respuestas originales; no usa
  imagenes para sintetizar.
- Salida base del LLM: JSON con `synthesized_answer_es`, `has_conflict`,
  `conflict_note` y `source_support_level`.
- Export final para fine-tuning: una fila por imagen del caso, con la respuesta
  sintetizada compactada como `answer_es`.

## Configuracion LLM documentada en el script

- Prompt version: `llm_synthesis_es_v5`.
- Deployment/modelo por defecto: `gpt-oss-120b`, configurable con
  `AZURE_OPENAI_DEPLOYMENT`.
- Proveedor: `LLM_PROVIDER=auto`, resolviendo a `foundry_v1` para endpoints de
  Azure AI Foundry (`services.ai.azure.com` o `/openai/v1`) y a
  `azure_openai` para Azure OpenAI clasico.
- API version por defecto: `2024-10-21`.
- Temperatura por defecto: `0.2`.
- Max tokens por defecto: `900`.
- Formato de respuesta: `json_schema` en modo `auto`, con fallback a
  `json_object` y luego JSON plano si el deployment no soporta schema estricto.

## Prompt y reglas de sintesis

El prompt del script le pide al modelo actuar como redactor clinico para VQA
dermatologico en espanol y devolver solo JSON valido. Las reglas principales
son:

- escribir una unica respuesta en espanol, de estilo clinico conciso;
- apuntar a 60-100 palabras cuando la informacion lo permita;
- usar solo informacion presente en las respuestas originales;
- no agregar diagnosticos, tratamientos, advertencias, recomendaciones,
  morfologia, signos negativos, causas ni hallazgos no mencionados;
- evitar respuestas de una sola palabra o solo etiqueta diagnostica;
- convertir etiquetas diagnosticas breves en una frase natural;
- no usar certeza absoluta salvo que aparezca explicitamente en las fuentes;
- no expandir siglas o abreviaturas si la fuente no las desarrolla;
- responder brevemente cuando la informacion fuente sea breve;
- integrar incertidumbre si hay contradicciones;
- marcar `has_conflict=true` solo ante contradiccion directa;
- no usar frases meta como "las respuestas", "las fuentes" o "los autores";
- no mencionar que esta unificando respuestas ni que es un modelo.

## Columnas del artefacto final

- `split`: `train`, `valid` o `test`.
- `encounter_id`: identificador del caso clinico.
- `image_id`: identificador de la imagen.
- `image_path`: ruta local de la imagen usada para el futuro flujo multimodal.
- `question_es`: pregunta del paciente en espanol.
- `answer_es`: respuesta enriquecida sintetizada a partir de las respuestas
  originales del caso.

## Conteos esperados y validados

| Split | Casos | Filas por imagen |
| --- | ---: | ---: |
| `train` | 842 | 2473 |
| `valid` | 56 | 157 |
| `test` | 100 | 314 |
| **Total** | **998** | **2944** |

Otros conteos:

- Imagenes unicas referenciadas: 2944.
- Casos con multiples imagenes: 773.
- Imagenes por caso: minimo 1, promedio 2.95, maximo 16.
- Filas JSONL: 2944.
- Filas CSV: 2944.

## Validacion realizada

Validado el 2026-06-16 contra los JSON fuente y los artefactos exportados:

- las parejas `(split, encounter_id, image_id)` del dataset coinciden con las
  esperadas desde los JSON fuente;
- faltantes respecto de fuente: 0;
- extras respecto de fuente: 0;
- preguntas vacias: 0;
- respuestas vacias: 0;
- `image_path` vacios: 0;
- archivos de imagen faltantes en las rutas locales actuales: 0;
- filas duplicadas completas: 0;
- duplicados por `(split, encounter_id, image_id)`: 0;
- el ZIP contiene JSONL, CSV, README y manifest.

## Limitaciones y pendientes

- La respuesta es sintetica: puede contener errores clinicos aunque el prompt
  limite la informacion a las respuestas originales.
- La sintesis no mira imagenes; la imagen queda solo como input futuro para VQA.
- La misma `answer_es` se repite para todas las imagenes de un mismo caso.
- `image_path` contiene rutas absolutas locales y debe remapearse en
  Colab/Kaggle u otra maquina.
- El artefacto compacto no conserva respuestas fuente, hash de fuente,
  `has_conflict`, `conflict_note`, `source_support_level`, proveedor ni modelo
  por fila.
- Costo aproximado: pendiente. No hay logs de `usage`, tokens ni costo en los
  artefactos versionables; para estimarlo hay que conservar/registrar usage de
  la corrida de Azure o recalcular sobre una nueva corrida controlada.
- No se incluyen secretos, `.env`, caches ni credenciales en estos documentos.
